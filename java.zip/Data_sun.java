public class Data_sun {
    //��� ����
    private int area_code;
    private float sunshine;

    //������
    public Data_sun(int _acode, int _sun){
        area_code = _acode;
        sunshine = _sun;
    }
    public Data_sun(){
        area_code = -1;
        sunshine = 0;
    }

    //getter, setter�Լ�
    public int getAreaCode(){
        return area_code;
    }

    public float getSunshine(){
        return sunshine;
    }

    public void setAreaCode(int _acode){
        area_code = _acode;
    }

    public void setSunshine(float _sun){
        sunshine = _sun;
    }

}
